import express from 'express';
import cors from 'cors';
import { createServer } from 'http';
import { Server } from 'socket.io';
import { v4 as uuidv4 } from 'uuid';

const app = express();
const httpServer = createServer(app);
const io = new Server(httpServer, {
  cors: {
    origin: 'http://localhost:5173',
    methods: ['GET', 'POST'],
  },
});

// Middleware
app.use(cors());
app.use(express.json());

// In-memory storage
const notifications = [];
const users = [
  { id: '1', name: 'John Doe', email: 'john@example.com', phone: '+1234567890' },
  { id: '2', name: 'Jane Smith', email: 'jane@example.com', phone: '+0987654321' },
];
const notificationQueue = [];
const failedNotifications = [];

// Queue processor (simulating async processing)
const processQueue = () => {
  if (notificationQueue.length > 0) {
    const notification = notificationQueue.shift();
    
    // Simulate success/failure (80% success rate)
    const isSuccess = Math.random() < 0.8;
    
    if (isSuccess) {
      // Add to notifications store
      notifications.push({
        ...notification,
        status: 'delivered',
        deliveredAt: new Date().toISOString(),
      });
      
      // Emit to specific user
      io.to(notification.userId).emit('notification', {
        ...notification,
        status: 'delivered',
      });
      
      console.log(`Processed notification: ${notification.id}`);
    } else {
      // Add to failed queue for retry
      if (notification.retryCount < 3) {
        notificationQueue.push({
          ...notification,
          retryCount: notification.retryCount + 1,
        });
        console.log(`Retrying notification: ${notification.id} (attempt ${notification.retryCount + 1})`);
      } else {
        notification.status = 'failed';
        notification.error = 'Max retries exceeded';
        failedNotifications.push(notification);
        console.log(`Failed to process notification after 3 retries: ${notification.id}`);
      }
    }
  }
};

// Process queue every 2 seconds
setInterval(processQueue, 2000);

// Socket connection
io.on('connection', (socket) => {
  console.log('Client connected:', socket.id);
  
  // Join user-specific room for targeted notifications
  socket.on('register', (userId) => {
    socket.join(userId);
    console.log(`User ${userId} registered for notifications`);
  });
  
  socket.on('disconnect', () => {
    console.log('Client disconnected:', socket.id);
  });
});

// API Routes
app.post('/notifications', (req, res) => {
  const { userId, type, message, title } = req.body;
  
  if (!userId || !type || !message) {
    return res.status(400).json({ error: 'Missing required fields' });
  }
  
  if (!['email', 'sms', 'in-app'].includes(type)) {
    return res.status(400).json({ error: 'Invalid notification type' });
  }
  
  const user = users.find(u => u.id === userId);
  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }
  
  const notification = {
    id: uuidv4(),
    userId,
    type,
    message,
    title: title || 'Notification',
    status: 'queued',
    createdAt: new Date().toISOString(),
    retryCount: 0,
    read: false,
  };
  
  // Add to queue
  notificationQueue.push(notification);
  
  res.status(201).json(notification);
});

app.get('/users/:id/notifications', (req, res) => {
  const userId = req.params.id;
  
  const user = users.find(u => u.id === userId);
  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }
  
  const userNotifications = notifications.filter(n => n.userId === userId);
  
  res.json(userNotifications);
});

app.put('/notifications/:id/read', (req, res) => {
  const { id } = req.params;
  
  const notification = notifications.find(n => n.id === id);
  if (!notification) {
    return res.status(404).json({ error: 'Notification not found' });
  }
  
  notification.read = true;
  notification.readAt = new Date().toISOString();
  
  res.json(notification);
});

// Server
const PORT = process.env.PORT || 3000;
httpServer.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});