import React, { createContext, useContext, useEffect, useState } from 'react';
import { io, Socket } from 'socket.io-client';
import { v4 as uuidv4 } from 'uuid';

// Types
export type NotificationType = 'email' | 'sms' | 'in-app';
export type NotificationStatus = 'queued' | 'delivered' | 'read' | 'failed';

export interface Notification {
  id: string;
  userId: string;
  type: NotificationType;
  title: string;
  message: string;
  status: NotificationStatus;
  createdAt: string;
  deliveredAt?: string;
  readAt?: string;
  read: boolean;
  retryCount?: number;
  error?: string;
}

export interface Toast {
  id: string;
  title: string;
  message: string;
  type: 'success' | 'error' | 'info' | 'warning';
}

interface NotificationContextType {
  notifications: Notification[];
  loading: boolean;
  error: string | null;
  fetchNotifications: (userId: string) => Promise<void>;
  markAsRead: (notificationId: string) => Promise<void>;
  sendNotification: (data: Omit<Notification, 'id' | 'status' | 'createdAt' | 'read' | 'retryCount'>) => Promise<void>;
  toasts: Toast[];
  addToast: (toast: Omit<Toast, 'id'>) => void;
  removeToast: (id: string) => void;
}

const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

const API_URL = 'http://localhost:3000';
const SOCKET_URL = 'http://localhost:3000';

export const NotificationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [socket, setSocket] = useState<Socket | null>(null);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [toasts, setToasts] = useState<Toast[]>([]);

  // Initialize socket connection
  useEffect(() => {
    const socketInstance = io(SOCKET_URL);
    setSocket(socketInstance);

    // Cleanup on unmount
    return () => {
      socketInstance.disconnect();
    };
  }, []);

  // Register user for notifications when socket is ready
  useEffect(() => {
    if (socket) {
      // For demo, we'll use a hardcoded user ID
      const userId = '1';
      socket.emit('register', userId);

      // Listen for notifications
      socket.on('notification', (notification: Notification) => {
        setNotifications(prev => [notification, ...prev]);
        
        // Add toast for new notification
        addToast({
          title: notification.title,
          message: notification.message,
          type: 'info',
        });
      });
    }
  }, [socket]);

  const fetchNotifications = async (userId: string) => {
    setLoading(true);
    try {
      const response = await fetch(`${API_URL}/users/${userId}/notifications`);
      if (!response.ok) {
        throw new Error('Failed to fetch notifications');
      }
      const data = await response.json();
      setNotifications(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
    } finally {
      setLoading(false);
    }
  };

  const markAsRead = async (notificationId: string) => {
    try {
      const response = await fetch(`${API_URL}/notifications/${notificationId}/read`, {
        method: 'PUT',
      });
      
      if (!response.ok) {
        throw new Error('Failed to mark notification as read');
      }
      
      // Update local state
      setNotifications(prev => 
        prev.map(notification => 
          notification.id === notificationId 
            ? { ...notification, read: true, readAt: new Date().toISOString() } 
            : notification
        )
      );
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
    }
  };

  const sendNotification = async (data: Omit<Notification, 'id' | 'status' | 'createdAt' | 'read' | 'retryCount'>) => {
    try {
      const response = await fetch(`${API_URL}/notifications`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });
      
      if (!response.ok) {
        throw new Error('Failed to send notification');
      }
      
      addToast({
        title: 'Notification Sent',
        message: 'Your notification has been queued for delivery',
        type: 'success',
      });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
      
      addToast({
        title: 'Error',
        message: err instanceof Error ? err.message : 'Failed to send notification',
        type: 'error',
      });
    }
  };

  const addToast = (toast: Omit<Toast, 'id'>) => {
    const newToast = { ...toast, id: uuidv4() };
    setToasts(prev => [newToast, ...prev]);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
      removeToast(newToast.id);
    }, 5000);
  };

  const removeToast = (id: string) => {
    setToasts(prev => prev.filter(toast => toast.id !== id));
  };

  return (
    <NotificationContext.Provider 
      value={{ 
        notifications, 
        loading, 
        error, 
        fetchNotifications, 
        markAsRead, 
        sendNotification,
        toasts,
        addToast,
        removeToast
      }}
    >
      {children}
    </NotificationContext.Provider>
  );
};

export const useNotifications = () => {
  const context = useContext(NotificationContext);
  if (context === undefined) {
    throw new Error('useNotifications must be used within a NotificationProvider');
  }
  return context;
};