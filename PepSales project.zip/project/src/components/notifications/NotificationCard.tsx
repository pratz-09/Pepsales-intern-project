import React from 'react';
import { CheckCircle2, AlertCircle, Clock, MessageSquare, Mail, Phone } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { Notification, useNotifications } from '../../context/NotificationContext';

interface NotificationCardProps {
  notification: Notification;
}

const NotificationCard: React.FC<NotificationCardProps> = ({ notification }) => {
  const { markAsRead } = useNotifications();

  const handleMarkAsRead = () => {
    if (!notification.read) {
      markAsRead(notification.id);
    }
  };

  const getStatusIcon = () => {
    switch (notification.status) {
      case 'delivered':
        return <CheckCircle2 className="h-5 w-5 text-green-500" />;
      case 'queued':
        return <Clock className="h-5 w-5 text-yellow-500" />;
      case 'failed':
        return <AlertCircle className="h-5 w-5 text-red-500" />;
      default:
        return <MessageSquare className="h-5 w-5 text-gray-500" />;
    }
  };

  const getTypeIcon = () => {
    switch (notification.type) {
      case 'email':
        return <Mail className="h-5 w-5 text-blue-500" />;
      case 'sms':
        return <Phone className="h-5 w-5 text-green-500" />;
      case 'in-app':
        return <MessageSquare className="h-5 w-5 text-purple-500" />;
      default:
        return <MessageSquare className="h-5 w-5 text-gray-500" />;
    }
  };

  const getTimeAgo = (dateString: string) => {
    return formatDistanceToNow(new Date(dateString), { addSuffix: true });
  };

  return (
    <div 
      className={`border rounded-lg shadow-sm p-4 transition-all duration-200 hover:shadow-md ${
        notification.read ? 'bg-white' : 'bg-blue-50'
      }`}
      onClick={handleMarkAsRead}
    >
      <div className="flex items-start gap-3">
        <div className="flex-shrink-0 mt-1">
          {getTypeIcon()}
        </div>
        <div className="flex-grow">
          <div className="flex justify-between items-start">
            <h3 className="font-medium text-gray-900">{notification.title}</h3>
            <div className="flex items-center gap-2">
              {getStatusIcon()}
              {!notification.read && (
                <span className="inline-flex items-center justify-center px-2 py-1 text-xs font-semibold text-blue-600 bg-blue-100 rounded-full">
                  New
                </span>
              )}
            </div>
          </div>
          <p className="text-gray-600 mt-1">{notification.message}</p>
          
          <div className="mt-3 flex justify-between items-center text-xs text-gray-500">
            <div className="flex items-center gap-2">
              <span className="capitalize">{notification.type}</span>
              <span>•</span>
              <span>{getTimeAgo(notification.createdAt)}</span>
            </div>
            
            <div className="flex gap-2">
              {notification.status === 'failed' && notification.error && (
                <span className="text-red-500">{notification.error}</span>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NotificationCard;