import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { Bell, Menu, X } from 'lucide-react';
import { useNotifications } from '../../context/NotificationContext';

const Header: React.FC = () => {
  const { notifications } = useNotifications();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const notificationRef = useRef<HTMLDivElement>(null);
  
  const unreadCount = notifications.filter(n => !n.read).length;

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (notificationRef.current && !notificationRef.current.contains(event.target as Node)) {
        setIsNotificationsOpen(false);
      }
    }

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  return (
    <header className="bg-white shadow">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center py-4">
          <div className="flex items-center">
            <Link to="/" className="text-xl font-bold text-indigo-600">
              Notify
            </Link>
          </div>

          {/* Desktop navigation */}
          <nav className="hidden md:flex items-center space-x-6">
            <Link to="/" className="text-gray-600 hover:text-indigo-600">
              Dashboard
            </Link>
            <Link to="/notifications" className="text-gray-600 hover:text-indigo-600">
              Notification Center
            </Link>
            <div className="relative" ref={notificationRef}>
              <button
                className="relative p-2 text-gray-600 hover:text-indigo-600 focus:outline-none"
                onClick={() => setIsNotificationsOpen(!isNotificationsOpen)}
              >
                <Bell className="h-6 w-6" />
                {unreadCount > 0 && (
                  <span className="absolute top-0 right-0 inline-flex items-center justify-center px-2 py-1 text-xs font-bold leading-none text-white transform translate-x-1/2 -translate-y-1/2 bg-red-500 rounded-full">
                    {unreadCount}
                  </span>
                )}
              </button>

              {isNotificationsOpen && (
                <div className="absolute right-0 mt-2 w-80 bg-white rounded-md shadow-lg overflow-hidden z-20">
                  <div className="py-2">
                    <div className="px-4 py-2 bg-gray-100 border-b">
                      <h3 className="text-sm font-semibold text-gray-700">Recent Notifications</h3>
                    </div>
                    <div className="max-h-96 overflow-y-auto">
                      {notifications.slice(0, 5).map((notification) => (
                        <Link
                          key={notification.id}
                          to="/notifications"
                          onClick={() => setIsNotificationsOpen(false)}
                          className={`block px-4 py-3 hover:bg-gray-50 transition duration-150 ease-in-out ${
                            !notification.read ? 'bg-blue-50' : ''
                          }`}
                        >
                          <div className="flex items-start">
                            <div className="flex-shrink-0">
                              <div className={`h-2 w-2 rounded-full ${getNotificationTypeColor(notification.type)}`}></div>
                            </div>
                            <div className="ml-3 w-full">
                              <p className="text-sm font-medium text-gray-900">{notification.title}</p>
                              <p className="text-sm text-gray-500 truncate">{notification.message}</p>
                              <p className="text-xs text-gray-400 mt-1">
                                {new Date(notification.createdAt).toLocaleTimeString()} · {notification.type}
                              </p>
                            </div>
                          </div>
                        </Link>
                      ))}

                      {notifications.length === 0 && (
                        <div className="px-4 py-6 text-center text-gray-500">
                          <p>No notifications yet</p>
                        </div>
                      )}
                    </div>
                    <div className="px-4 py-2 bg-gray-100 border-t">
                      <Link
                        to="/notifications"
                        onClick={() => setIsNotificationsOpen(false)}
                        className="block text-center text-sm font-medium text-indigo-600 hover:text-indigo-500"
                      >
                        View all notifications
                      </Link>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </nav>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <button
              type="button"
              className="text-gray-600 hover:text-indigo-600 focus:outline-none"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? (
                <X className="h-6 w-6" />
              ) : (
                <Menu className="h-6 w-6" />
              )}
            </button>
          </div>
        </div>

        {/* Mobile navigation */}
        {isMenuOpen && (
          <div className="md:hidden py-4 border-t">
            <nav className="flex flex-col space-y-4">
              <Link
                to="/"
                className="text-gray-600 hover:text-indigo-600"
                onClick={() => setIsMenuOpen(false)}
              >
                Dashboard
              </Link>
              <Link
                to="/notifications"
                className="text-gray-600 hover:text-indigo-600"
                onClick={() => setIsMenuOpen(false)}
              >
                Notification Center
              </Link>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

function getNotificationTypeColor(type: string): string {
  switch (type) {
    case 'email':
      return 'bg-blue-500';
    case 'sms':
      return 'bg-green-500';
    case 'in-app':
      return 'bg-purple-500';
    default:
      return 'bg-gray-500';
  }
}

export default Header;