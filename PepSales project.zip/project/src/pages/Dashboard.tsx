import React, { useEffect } from 'react';
import NotificationForm from '../components/notifications/NotificationForm';
import { useNotifications } from '../context/NotificationContext';
import { Bell, Clock, CheckCircle2, AlertCircle } from 'lucide-react';

const Dashboard: React.FC = () => {
  const { notifications, fetchNotifications } = useNotifications();

  useEffect(() => {
    // For demo, we'll use a hardcoded user ID
    fetchNotifications('1');
  }, [fetchNotifications]);

  // Count notifications by status
  const counts = {
    total: notifications.length,
    unread: notifications.filter(n => !n.read).length,
    delivered: notifications.filter(n => n.status === 'delivered').length,
    queued: notifications.filter(n => n.status === 'queued').length,
    failed: notifications.filter(n => n.status === 'failed').length,
  };

  // Count notifications by type
  const typeCounts = {
    email: notifications.filter(n => n.type === 'email').length,
    sms: notifications.filter(n => n.type === 'sms').length,
    inApp: notifications.filter(n => n.type === 'in-app').length,
  };

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard 
          title="Total Notifications" 
          value={counts.total} 
          icon={<Bell className="h-6 w-6 text-indigo-500" />}
          color="bg-indigo-50 text-indigo-500"
        />
        <StatCard 
          title="Unread" 
          value={counts.unread} 
          icon={<Bell className="h-6 w-6 text-blue-500" />}
          color="bg-blue-50 text-blue-500"
        />
        <StatCard 
          title="Delivered" 
          value={counts.delivered} 
          icon={<CheckCircle2 className="h-6 w-6 text-green-500" />}
          color="bg-green-50 text-green-500"
        />
        <StatCard 
          title="Failed" 
          value={counts.failed} 
          icon={<AlertCircle className="h-6 w-6 text-red-500" />}
          color="bg-red-50 text-red-500"
        />
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white rounded-lg shadow p-4">
          <h3 className="font-medium text-gray-700 mb-2">By Type</h3>
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Email</span>
              <div className="flex items-center">
                <div className="h-2.5 bg-blue-500 rounded-full mr-2" style={{ width: `${(typeCounts.email / Math.max(counts.total, 1)) * 100}px` }}></div>
                <span className="text-sm font-medium text-gray-900">{typeCounts.email}</span>
              </div>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">SMS</span>
              <div className="flex items-center">
                <div className="h-2.5 bg-green-500 rounded-full mr-2" style={{ width: `${(typeCounts.sms / Math.max(counts.total, 1)) * 100}px` }}></div>
                <span className="text-sm font-medium text-gray-900">{typeCounts.sms}</span>
              </div>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">In-App</span>
              <div className="flex items-center">
                <div className="h-2.5 bg-purple-500 rounded-full mr-2" style={{ width: `${(typeCounts.inApp / Math.max(counts.total, 1)) * 100}px` }}></div>
                <span className="text-sm font-medium text-gray-900">{typeCounts.inApp}</span>
              </div>
            </div>
          </div>
        </div>
        
        <div className="md:col-span-2">
          <NotificationForm />
        </div>
      </div>
    </div>
  );
};

interface StatCardProps {
  title: string;
  value: number;
  icon: React.ReactNode;
  color: string;
}

const StatCard: React.FC<StatCardProps> = ({ title, value, icon, color }) => {
  return (
    <div className="bg-white rounded-lg shadow p-4">
      <div className="flex items-center">
        <div className={`p-2 rounded-full ${color}`}>
          {icon}
        </div>
        <div className="ml-4">
          <p className="text-sm font-medium text-gray-500">{title}</p>
          <p className="text-2xl font-semibold text-gray-900">{value}</p>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;