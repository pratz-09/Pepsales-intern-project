import React, { useEffect, useState } from 'react';
import { useNotifications } from '../context/NotificationContext';
import NotificationCard from '../components/notifications/NotificationCard';
import { Search, Filter } from 'lucide-react';

const NotificationCenter: React.FC = () => {
  const { notifications, loading, fetchNotifications } = useNotifications();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<string | null>(null);
  const [filterStatus, setFilterStatus] = useState<string | null>(null);

  useEffect(() => {
    // For demo, we'll use a hardcoded user ID
    fetchNotifications('1');
  }, [fetchNotifications]);

  const filteredNotifications = notifications.filter(notification => {
    // Filter by search term
    const matchesSearch = searchTerm === '' || 
      notification.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      notification.message.toLowerCase().includes(searchTerm.toLowerCase());
    
    // Filter by type
    const matchesType = filterType === null || notification.type === filterType;
    
    // Filter by status
    const matchesStatus = filterStatus === null || notification.status === filterStatus;
    
    return matchesSearch && matchesType && matchesStatus;
  });

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Notification Center</h1>
        <p className="text-gray-600 mt-1">View and manage all your notifications</p>
      </div>
      
      <div className="bg-white rounded-lg shadow">
        <div className="p-4 border-b">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="relative flex-grow">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="text"
                placeholder="Search notifications..."
                className="pl-10 w-full border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="relative inline-block">
                <label htmlFor="typeFilter" className="sr-only">Filter by type</label>
                <select
                  id="typeFilter"
                  className="border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500 pl-3 pr-8 py-2"
                  value={filterType || ''}
                  onChange={(e) => setFilterType(e.target.value || null)}
                >
                  <option value="">All Types</option>
                  <option value="email">Email</option>
                  <option value="sms">SMS</option>
                  <option value="in-app">In-App</option>
                </select>
                <div className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none">
                  <Filter className="h-4 w-4 text-gray-400" />
                </div>
              </div>
              <div className="relative inline-block">
                <label htmlFor="statusFilter" className="sr-only">Filter by status</label>
                <select
                  id="statusFilter"
                  className="border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500 pl-3 pr-8 py-2"
                  value={filterStatus || ''}
                  onChange={(e) => setFilterStatus(e.target.value || null)}
                >
                  <option value="">All Statuses</option>
                  <option value="delivered">Delivered</option>
                  <option value="queued">Queued</option>
                  <option value="failed">Failed</option>
                </select>
                <div className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none">
                  <Filter className="h-4 w-4 text-gray-400" />
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="p-4">
          {loading ? (
            <div className="flex justify-center items-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
            </div>
          ) : filteredNotifications.length > 0 ? (
            <div className="space-y-4">
              {filteredNotifications.map((notification) => (
                <NotificationCard key={notification.id} notification={notification} />
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-12">
              <p className="text-gray-500 text-lg mb-2">No notifications found</p>
              <p className="text-gray-400">
                {searchTerm || filterType || filterStatus ? 
                  'Try adjusting your filters' : 
                  'You don\'t have any notifications yet'}
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default NotificationCenter;